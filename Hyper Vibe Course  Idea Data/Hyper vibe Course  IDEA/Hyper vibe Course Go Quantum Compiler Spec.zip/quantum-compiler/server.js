// quantum-compiler/server.js - HyperCode Quantum Esoteric Compiler (Node.js)
const http = require('http');
const url = require('url');

// Brainfuck to Quantum map (simple loop unroll to gates)
const bfToQuantum = {
  '+': "rx(pi/8, q[0])",      // Increment → small rotation
  '-': "rx(-pi/8, q[0])",     // Decrement → negative rotation
  '>': "swap(q[0],q[1])",     // Move right → swap qubits
  '<': "swap(q[0],q[1])",     // Move left → swap qubits
  '[': "// loop start",       // Loop start (simplified)
  ']': "// loop end",         // Loop end (simplified)
  '.': "measure(q[0], c[0])", // Output → measure
  ',': "h(q[0])",             // Input → Hadamard (superposition)
};

function compileBF(source) {
  const quantum = [];
  quantum.push("from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister");
  quantum.push("");
  quantum.push("# Create quantum and classical registers");
  quantum.push("qr = QuantumRegister(2, 'q')");
  quantum.push("cr = ClassicalRegister(2, 'c')");
  quantum.push("qc = QuantumCircuit(qr, cr)");
  quantum.push("");
  quantum.push("# Compiled from Brainfuck");
  quantum.push(`# Original: ${source}`);
  quantum.push("");

  for (let i = 0; i < source.length; i++) {
    const gate = bfToQuantum[source[i]];
    if (gate) {
      quantum.push(`qc.${gate}`);
    }
  }

  quantum.push("");
  quantum.push("# Measure all qubits");
  quantum.push("qc.measure_all()");
  quantum.push("");
  quantum.push("# Print the circuit");
  quantum.push("print(qc)");
  quantum.push("print(qc.draw(output='text'))");

  return quantum.join("\n");
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // Set CORS headers
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Health check endpoint
  if (pathname === '/quantum-compiler/health') {
    res.writeHead(200);
    res.end(JSON.stringify({
      status: 'healthy',
      service: 'quantum-compiler',
      version: '1.0.0'
    }, null, 2));
    return;
  }

  // Compile endpoint
  if (pathname === '/quantum-compiler/compile') {
    let bfCode = '';

    if (method === 'POST') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          const data = JSON.parse(body);
          bfCode = data.code || '';
        } catch (e) {
          res.writeHead(400);
          res.end(JSON.stringify({
            success: false,
            message: 'Invalid JSON: ' + e.message
          }, null, 2));
          return;
        }
        handleCompile(bfCode, res);
      });
      return;
    } else {
      // GET request
      bfCode = parsedUrl.query.code || '';
      handleCompile(bfCode, res);
      return;
    }
  }

  // Root endpoint
  if (pathname === '/') {
    res.writeHead(200);
    res.end(JSON.stringify({
      service: 'HyperCode Quantum Esoteric Compiler',
      version: '1.0.0',
      endpoints: [
        '/quantum-compiler/compile - Compile Brainfuck to Qiskit',
        '/quantum-compiler/health  - Health check'
      ],
      usage: 'POST /quantum-compiler/compile with JSON body: {"code": "++++[>++<-]"}'
    }, null, 2));
    return;
  }

  // 404 for unknown paths
  res.writeHead(404);
  res.end(JSON.stringify({
    success: false,
    message: 'Not found'
  }, null, 2));
});

function handleCompile(bfCode, res) {
  if (!bfCode) {
    res.writeHead(400);
    res.end(JSON.stringify({
      success: false,
      message: "No Brainfuck code provided. Use 'code' parameter."
    }, null, 2));
    return;
  }

  const qCode = compileBF(bfCode);
  
  res.writeHead(200);
  res.end(JSON.stringify({
    success: true,
    quantum_code: qCode,
    message: 'Compilation successful'
  }, null, 2));
}

const PORT = 8081;
server.listen(PORT, () => {
  console.log(`🚀 Quantum Compiler starting on http://localhost:${PORT}`);
  console.log(`📡 Endpoints:`);
  console.log(`   - POST/GET /quantum-compiler/compile?code=<brainfuck>`);
  console.log(`   - GET /quantum-compiler/health`);
  console.log(`\n🧪 Test: curl "http://localhost:${PORT}/quantum-compiler/compile?code=++++[>++<-]"`);
});
