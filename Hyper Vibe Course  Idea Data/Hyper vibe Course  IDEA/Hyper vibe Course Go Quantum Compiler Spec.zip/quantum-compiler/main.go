// quantum-compiler/main.go - HyperCode Quantum Esoteric Compiler
package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
)

// Brainfuck to Quantum map (simple loop unroll to gates)
var bfToQuantum = map[byte]string{
	'+': "rx(pi/8, q[0])",     // Increment → small rotation
	'-': "rx(-pi/8, q[0])",    // Decrement → negative rotation
	'>': "swap(q[0],q[1])",    // Move right → swap qubits
	'<': "swap(q[0],q[1])",    // Move left → swap qubits
	'[': "// loop start",      // Loop start (simplified)
	']': "// loop end",        // Loop end (simplified)
	'.': "measure(q[0], c[0])", // Output → measure
	',': "h(q[0])",            // Input → Hadamard (superposition)
}

// CompileRequest represents the incoming compilation request
type CompileRequest struct {
	Code string `json:"code"`
}

// CompileResponse represents the compilation result
type CompileResponse struct {
	Success    bool   `json:"success"`
	QuantumCode string `json:"quantum_code"`
	Message    string `json:"message,omitempty"`
}

func compileBF(source string) string {
	var quantum []string
	quantum = append(quantum, "from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister")
	quantum = append(quantum, "")
	quantum = append(quantum, "# Create quantum and classical registers")
	quantum = append(quantum, "qr = QuantumRegister(2, 'q')")
	quantum = append(quantum, "cr = ClassicalRegister(2, 'c')")
	quantum = append(quantum, "qc = QuantumCircuit(qr, cr)")
	quantum = append(quantum, "")
	quantum = append(quantum, "# Compiled from Brainfuck")
	quantum = append(quantum, "# Original: "+source)
	quantum = append(quantum, "")

	for i := 0; i < len(source); i++ {
		if gate, ok := bfToQuantum[source[i]]; ok {
			quantum = append(quantum, "qc."+gate)
		}
	}

	quantum = append(quantum, "")
	quantum = append(quantum, "# Measure all qubits")
	quantum = append(quantum, "qc.measure_all()")
	quantum = append(quantum, "")
	quantum = append(quantum, "# Print the circuit")
	quantum = append(quantum, "print(qc)")
	quantum = append(quantum, "print(qc.draw(output='text'))")

	return strings.Join(quantum, "\n")
}

func compileHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	var bfCode string

	if r.Method == "POST" {
		var req CompileRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			json.NewEncoder(w).Encode(CompileResponse{
				Success: false,
				Message: "Invalid JSON: " + err.Error(),
			})
			return
		}
		bfCode = req.Code
	} else {
		// GET request - read from query parameter
		bfCode = r.URL.Query().Get("code")
	}

	if bfCode == "" {
		json.NewEncoder(w).Encode(CompileResponse{
			Success: false,
			Message: "No Brainfuck code provided. Use 'code' parameter.",
		})
		return
	}

	qCode := compileBF(bfCode)
	
	json.NewEncoder(w).Encode(CompileResponse{
		Success:     true,
		QuantumCode: qCode,
		Message:     "Compilation successful",
	})
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"status":  "healthy",
		"service": "quantum-compiler",
		"version": "1.0.0",
	})
}

func main() {
	http.HandleFunc("/quantum-compiler/compile", compileHandler)
	http.HandleFunc("/quantum-compiler/health", healthHandler)
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"service": "HyperCode Quantum Esoteric Compiler",
			"version": "1.0.0",
			"endpoints": []string{
				"/quantum-compiler/compile - Compile Brainfuck to Qiskit",
				"/quantum-compiler/health  - Health check",
			},
			"usage": "POST /quantum-compiler/compile with JSON body: {\"code\": \"++++[>++<-]\"}",
		})
	})

	port := ":8081"
	fmt.Printf("🚀 Quantum Compiler starting on http://localhost%s\n", port)
	fmt.Printf("📡 Endpoints:\n")
	fmt.Printf("   - POST/GET /quantum-compiler/compile?code=<brainfuck>\n")
	fmt.Printf("   - GET /quantum-compiler/health\n")
	fmt.Printf("\n🧪 Test: curl \"http://localhost%s/quantum-compiler/compile?code=++++[>++<-]\"\n", port)
	
	if err := http.ListenAndServe(port, nil); err != nil {
		fmt.Printf("Error starting server: %v\n", err)
	}
}
